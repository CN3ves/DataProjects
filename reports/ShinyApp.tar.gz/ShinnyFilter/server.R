library('shiny')
library('tiff')

shinyServer(function(input, output) {
  
  
  find.box<- function () {
    scale<-as.numeric(input$scale )
    box.length<-as.numeric(input$box)
    pixels<-box.length/scale
    box<-(pixels-1)/2
    return (box)
  }
  top_row_sums <- function (image,b) {
    sums <- numeric()
    for (j in 1:ncol(image)){
      range.j<-(j-b):(j+b)
      range.j<-range.j[which(0<range.j & range.j<=ncol(image))]
      range.i <- 1:(b+1)
      
      sum<- sum(image[range.i,range.j])
      sums<-append(sums,sum)
    }
    return (sums)
  }
  columns_sums <-function (image,b) {
    
    sums <- matrix(rep(0,length(image)),nrow(image),ncol(image))
    sums[1,]<-top_row_sums(image,b)
    
    range.i <- 1:(b+1)
    for (j in 1:length(sums[1,])){
      range.j<-(j-b):(j+b)
      range.j<-range.j[which(0<range.j & range.j<=ncol(image))]
      range.i <- 1:(b+1)
      begin = TRUE
      
      for (i in 2:nrow(image)){
        
        if (length(range.i)<(2*b+1) & begin==TRUE){
          range.i<-append(range.i,range.i[length(range.i)]+1)
          
          sum<-sum(image[range.i[length(range.i)], range.j])
          minus<-0
        }else{
          begin = FALSE
          range.i<-range.i+1
          
          if (range.i[length(range.i)]<=nrow(image)){
            sum<-sum(image[range.i[length(range.i)], range.j])
            
          }else {sum=0}
          minus<-sum(image[range.i[1]-1, range.j])
          
        }
        sums[i,j]<-sums[i-1,j]+sum-minus
        
      }
    }
    return(sums)
  }
  filter <- function(image,b) {
    if (sum(image) < 10) {
      return(image)
    }else {
    sum.matrix<-columns_sums(image,b)
    area<-(2*b+1)^2
    weight<-sum.matrix/area
    image<-image-weight
    image[image<=0.1]<-0
    image[image>0.9]<-0.9
    image[image>=0.1]<-image[image>=0.1]*(1/max(image))
    return(image)
    }
  }
  new.image <- function() ({
    image.file<-input$image
    image <- readTIFF(image.file$datapath)
    for (color in 1:dim(image)[3]){image[,,color]<- filter(image[,,color],find.box())}
    return(image) 
  })  
  
  output$downloadData <- downloadHandler(
    filename = function() {return('Filtered.tif')},
    content = function(file) {writeTIFF(new.image(), file)}
  )  
  
 
})
