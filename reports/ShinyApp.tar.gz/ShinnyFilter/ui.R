library('shiny')


shinyUI(fluidPage(
  titlePanel("ShinyFilter"),
  tabsetPanel(
        
    tabPanel("Image filter",

      titlePanel("High-pass filtration"),

      sidebarLayout(

        sidebarPanel(
          fileInput('image', 'Upload Tiff file:',
                       accept=c('image/tif','.tif')),
          downloadButton('downloadData', 'Download'),
          p(a("Sample Image", href="Microscopy_test.tif", target="_blank"))
        ),
        mainPanel(
          
          h4("Filter options:"),
          textInput("scale","Scale - μm per pixel:","0.3"),
          textInput("box","Box length:","7.5")
        )
      )

    ),

    tabPanel("Instructions",

      h4("Filter steps:"),

      p('1) Upload a local file from your computer'),
      p('2) Once an image is uploaded to the served, select the scale and box length.'),
      p('3) Press download to save the processed image') ,

      p(a("Documentation",href="Readme.html", target="_blank"))  

    )

  )
))
    
    