DNAm_clock <- function(betas, folder = "./DNAmClock") {
  
  #Age transformation and probe annotation functions
  trafo= function(x,adult.age=20) { x=(x+1)/(1+adult.age); y=ifelse(x<=1, log( x),x-1);y }
  anti.trafo= function(x,adult.age=20) { ifelse(x<0, (1+adult.age)*exp(x)-1, (1+adult.age)*x+adult.age)}
  
  probeAnnotation21kdatMethUsed=read.csv(paste0(folder, "/Annotation21K.csv") )
  probeAnnotation27k=read.csv(paste0(folder, "/Annotation27k.csv") )
  datClock=read.csv(paste0(folder, "/predictor.csv"))
  
  #Read in the DNA methylation data (beta values)
  dat0 <- betas[grep("^cg", rownames(betas)), ]
  dat0 <- data.frame("ProbeID" = rownames(dat0), dat0)
  
  nSamples=dim(dat0)[[2]]-1
  nProbes= dim(dat0)[[1]]
  
  #Sample check
  DoNotProceed=FALSE
  
  if (nSamples==0) {DoNotProceed=TRUE; print("\n ERROR: There must be a data input error since there seem to be no samples")} 
  if (nProbes==0) {DoNotProceed=TRUE; print("\n ERROR: There must be a data input error since there seem to be zero probes")} 
  if (  nSamples > nProbes  ) { print("\n MAJOR WARNING: There are more samples than CpG probes.\n Make sure that probes correspond to rows and samples to columns.")}
  if (  is.numeric(dat0[,1]) ) { DoNotProceed=TRUE; print("\n ERROR: The first column does not seem to contain probe identifiers (cg numbers from Illumina) since these entries are numeric values")} 
  
  datout=data.frame(Error=c("Input error. Please check the log file for details","Please read the instructions carefully."), Comment=c("", "email Steve Horvath."))
  if ( ! DoNotProceed ) {
    nonNumericColumn=rep(FALSE, dim(dat0)[[2]]-1)
    for (i in 2:dim(dat0)[[2]] ){ nonNumericColumn[i-1]=! is.numeric(dat0[,i]) }
    if (  sum(nonNumericColumn) >0 ) { print(paste( "\n MAJOR WARNING: Possible input error. The following samples contain non-numeric beta values: ", colnames(dat0)[-1][ nonNumericColumn] ))  } 
    
    # Sex chromossome estimation, the values are needed downstream, but the outcome is not required here
    XchromosomalCpGs=as.character(probeAnnotation27k$Name[probeAnnotation27k$Chr=="X"])
    selectXchromosome=is.element(dat0[,1], XchromosomalCpGs )
    selectXchromosome[is.na(selectXchromosome)]=FALSE
    meanXchromosome=rep(NA, dim(dat0)[[2]]-1)
    
    match1=match(probeAnnotation21kdatMethUsed$Name , dat0[,1])
    if  ( sum( is.na(match1))>0 ) { 
      missingProbes= probeAnnotation21kdatMethUsed$Name[!is.element( probeAnnotation21kdatMethUsed$Name , dat0[,1])]    
      DoNotProceed=TRUE; print(paste( "\n \n Input error: You forgot to include the following ", length(missingProbes), " CpG probes (or probe names):\n ", paste( missingProbes, sep="",collapse=", ")))  
    } 
    
    # Restrict the data to 21k probes and ensure they are numeric
    match1=match(probeAnnotation21kdatMethUsed$Name , dat0[,1])
    if  ( sum( is.na(match1))>0 ) stop(paste(sum( is.na(match1)), "CpG probes cannot be matched"))
    
    dat1 <- dat0[match1,]
    asnumeric1=function(x) {as.numeric(as.character(x))}
    dat1[,-1]<-apply(as.matrix(dat1[,-1]),2,asnumeric1)
    
    #Create the output file called datout
    set.seed(1)
    
    normalizeData=TRUE
    source(paste0(folder, "/Normalization.txt"), local = TRUE)
    source(paste0(folder, "/Analysis.txt"), local = TRUE)
    
    #  Output the results 
    if (  sum(  datout$Comment  != "" )   ==0 ) { cat(paste( "\n The individual samples appear to be fine. "),file="LogFile.txt",append=TRUE)  } 
    if (  sum(  datout$Comment != "" )   >0 ) { cat(paste( "\n Warnings were generated for the following samples.\n", datout[,1][datout$Comment != ""], "\n Hint: Check the output file for more details."),file="LogFile.txt",append=TRUE)  } 
    
  } 
  
  return(datout)
}